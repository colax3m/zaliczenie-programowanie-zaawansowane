﻿using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Text.Json;

namespace ConsoleClient3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            const int CLIENT_ID = 3;

            byte[] bytes = new byte[1024];
            var possibleOptions = new string[]
            {
                "GET_CATS",
                "GET_DOGS",
                "GET_CARS"
            };
            var random = new Random();

            try
            {
                var host = Dns.GetHostEntry("localhost");
                var ipAddress = host.AddressList[0];
                var localEndpoint = new IPEndPoint(ipAddress, 11000);

                var sender = new Socket(ipAddress.AddressFamily, SocketType.Stream, ProtocolType.Tcp);

                try
                {
                    sender.Connect(localEndpoint);

                    Console.WriteLine($"Połączono z {sender.RemoteEndPoint}");

                    sender.Send(BitConverter.GetBytes(CLIENT_ID));

                    int bytesRec = sender.Receive(bytes);
                    var textReceived = Encoding.ASCII.GetString(bytes, 0, bytesRec);

                    if (textReceived != "OK")
                    {
                        Console.WriteLine("Serwer nie pozwolił na połączenie.");

                        return;
                    }

                    for (int i = 0; i < 3; i++)
                    {
                        var optionId = random.Next(0, possibleOptions.Length);
                        var option = possibleOptions[optionId];

                        var message = Encoding.ASCII.GetBytes(option);

                        var bytesSent = sender.Send(message);

                        bytesRec = sender.Receive(bytes);
                        var objectsReceived = Encoding.ASCII.GetString(bytes, 0, bytesRec);

                        switch (option)
                        {
                            case "GET_CATS":
                                var cats = JsonSerializer.Deserialize<IEnumerable<Cat>>(objectsReceived);

                                foreach (var cat in cats)
                                {
                                    Console.WriteLine($"Kot. Imię: {cat.Name}");
                                }

                                break;
                            case "GET_DOGS":
                                var dogs = JsonSerializer.Deserialize<IEnumerable<Dog>>(objectsReceived);

                                foreach (var dog in dogs)
                                {
                                    Console.WriteLine($"Pies. Imię: {dog.Name}");
                                }

                                break;
                            case "GET_CARS":
                                var cars = JsonSerializer.Deserialize<IEnumerable<Car>>(objectsReceived);

                                foreach (var car in cars)
                                {
                                    Console.WriteLine($"Samochód. Kolor: {car.Color}");
                                }

                                break;
                            default:
                                break;
                        }
                    }

                    sender.Send(Encoding.ASCII.GetBytes("END"));

                    sender.Shutdown(SocketShutdown.Both);
                    sender.Close();
                }
                catch (JsonException)
                {
                    Console.WriteLine("Nie udało się zdeserializować.");
                }
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception.ToString());
            }
        }
    }

    public class Car
    {
        public string Color { get; set; }

        public Car(string color)
        {
            Color = color;
        }
    }

    public class Cat
    {
        public string Name { get; set; }

        public Cat(string name)
        {
            Name = name;
        }
    }

    public class Dog
    {
        public string Name { get; set; }

        public Dog(string name)
        {
            Name = name;
        }
    }
}