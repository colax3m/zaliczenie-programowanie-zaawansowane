﻿using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Text.Json;

namespace ConsoleServer
{
    public class Program
    {
        const int MAX_CLIENTS = 2;
        static Random random = new();
        static List<int> connectedClients = new();
        static Dictionary<string, object> objects = CreateObjects();

        static async Task Main(string[] args)
        {            
            var host = Dns.GetHostEntry("localhost");
            var ipAddress = host.AddressList[0];
            var localEndpoint = new IPEndPoint(ipAddress, 11000);                                                         

            try
            {               
                Console.WriteLine("Oczekiwanie na połączenie.");                                               

                var listener = new Socket(ipAddress.AddressFamily, SocketType.Stream, ProtocolType.Tcp);
                listener.Bind(localEndpoint);
                listener.Listen(10);                

                while (true)
                {
                    var handler = listener.Accept();                    

                    var task = Task.Run(() => ProcessClient(handler));                    
                }                
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception.ToString());
            }            
        }        

        private static Dictionary<string, object> CreateObjects()
        {
            var dictionary = new Dictionary<string, object>();

            for(int i = 1; i <= 4; i++)
            {
                dictionary.Add("kot_" + i, new Cat("imie_kota_" + i));
                dictionary.Add("pies_" + i, new Dog("imie_psa_" + i));
                dictionary.Add("samochod_" + i, new Car("kolor_samochodu_" + i));
            }

            return dictionary;
        }

        private static async Task ProcessClient(Socket handler)
        {            
            if (connectedClients.Count == MAX_CLIENTS)
            {
                Console.WriteLine("Osiągnięto maksymalną liczbę klientów. Odmowa połączenia następnego klienta.");

                await handler.SendAsync(Encoding.ASCII.GetBytes("REFUSED"), SocketFlags.None);

                await handler.DisconnectAsync(true);

                return;
            }

            var bytes = new byte[2048];
            await handler.ReceiveAsync(bytes, SocketFlags.None);

            var clientId = BitConverter.ToInt32(bytes, 0);
            connectedClients.Add(clientId);

            Console.WriteLine("Połączono z klientem o id " + clientId);

            var delay = random.Next(1000, 10000);
            await Task.Delay(delay);

            handler.Send(Encoding.ASCII.GetBytes("OK"));

            while (true)
            {
                int receivedBytes = await handler.ReceiveAsync(bytes, SocketFlags.None);

                var message = Encoding.ASCII.GetString(bytes, 0, receivedBytes);

                if (message == "END")
                {
                    Console.WriteLine($"Rozłączono z klientem o id {clientId}");

                    await handler.DisconnectAsync(true);
                    connectedClients.Remove(clientId);
                    break;
                }

                List<object> objectsToSend;

                switch (message)
                {
                    case "GET_CATS":
                        objectsToSend = objects.Where(x => x.Key.Contains("kot")).Select(x => x.Value).ToList();
                        Console.WriteLine($"Wysłano koty do klienta o id {clientId}");
                        break;
                    case "GET_DOGS":
                        objectsToSend = objects.Where(x => x.Key.Contains("pies")).Select(x => x.Value).ToList();
                        Console.WriteLine($"Wysłano psy do klienta o id {clientId}");
                        break;
                    case "GET_CARS":
                        objectsToSend = objects.Where(x => x.Key.Contains("samochod")).Select(x => x.Value).ToList();
                        Console.WriteLine($"Wysłano samochody do klienta o id {clientId}");
                        break;
                    default:
                        objectsToSend = new List<object> { objects.First() };
                        break;
                }

                await handler.SendAsync(Encoding.ASCII.GetBytes(JsonSerializer.Serialize(objectsToSend)), SocketFlags.None);
            }
        }
    }
}