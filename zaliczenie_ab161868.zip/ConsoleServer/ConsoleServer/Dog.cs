﻿namespace ConsoleServer
{
    public class Dog
    {
        public string Name { get; set; }

        public Dog(string name)
        {
            Name = name;
        }
    }
}
