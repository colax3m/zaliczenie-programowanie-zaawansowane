﻿namespace ConsoleServer
{
    public class Car
    {
        public string Color { get; set; }

        public Car(string color)
        {
            Color = color;   
        }
    }
}
