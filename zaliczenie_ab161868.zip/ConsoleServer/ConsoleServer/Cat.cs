﻿namespace ConsoleServer
{
    public class Cat
    {
        public string Name {  get; set; }
        
        public Cat(string name)
        {
            Name = name;
        }
    }
}
